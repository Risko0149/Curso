/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.Random;

/**
 * @author tomyv
 *
 *
 * Realizar el juego de la ruleta rusa de agua en Java. Como muchos saben, el
 * juego se trata de un número de jugadores, que, con un revolver de agua, el
 * cual posee una sola carga de agua, se dispara y se moja. Las clases por hacer
 * del juego son las siguientes:
 * 
 * Clase Revolver de agua: esta clase posee los siguientes atributos: posición actual
 * (posición del tambor que se dispara,puede que esté el agua o no) y posición agua
 * (la posición del tambor donde se encuentra el agua).
 * Estas dos posiciones, se generarán aleatoriamente.
 *
 * Métodos:
 *
 * 
 *
 * 
 *
 * 
 *
 * 
 *
 */
public class Revolver {
        
    private int posTambor;
    private int posAgua;

    public Revolver() {
    }

    public Revolver(int posTambor, int posAgua) {
        this.posTambor = posTambor;
        this.posAgua = posAgua;
    }

    public int getPosTambor() {
        return posTambor;
    }

    public void setPosTambor(int posTambor) {
        this.posTambor = posTambor;
    }

    public int getPosAgua() {
        return posAgua;
    }

    public void setPosAgua(int posAgua) {
        this.posAgua = posAgua;
    }

    
    
    @Override
    public String toString() {
        return "RevolverDeAgua{" + "posTambor=" + posTambor + ", posAgua=" + posAgua + '}';
    }
    
    
    
}
