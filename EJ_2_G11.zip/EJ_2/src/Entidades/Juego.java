package Entidades;

import Service.All;
import java.util.ArrayList;
import java.util.Scanner;

//Clase Juego: esta clase posee los siguientes atributos: Jugadores (conjunto de Jugadores) y
//Revolver
public class Juego {

    private ArrayList<Jugador> player = new ArrayList() ;
    private Revolver pistol = new Revolver();
    private All a = new All();

    
    // • llenarJuego(ArrayList<Jugador>jugadores, Revolver r): este método recibe los jugadores
    // y el revolver para guardarlos en los atributos del juego.
    public void llenarJuego() {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        Integer c = 0;
        do {
            System.out.println("NAME");
            Jugador jug = new Jugador();
            jug.setName(sc.next());
            jug.setId(c);
            c++;
            jug.setId(c);
            player.add(jug);
            System.out.println("OTHER PLAYERRR?? (Y/N)");
        } while ("Y".equalsIgnoreCase(sc.next()));
        
        if(c>1){
            a.llenarRevolver(pistol);
        }
        
        
    }

    //• ronda(): cada ronda consiste en un jugador que se apunta con el revolver de agua y
    //aprieta el gatillo. Sí el revolver tira el agua el jugador se moja y se termina el juego, sino se
    //moja, se pasa al siguiente jugador hasta que uno se moje. Si o si alguien se tiene que
    //mojar. Al final del juego, se debe mostrar que jugador se mojó.
    //Pensar la lógica necesaria para realizar esto, usando los atributos de la clase Juego.
    public void ronda() {
        llenarJuego();
        for (Jugador aux : player) {
            if(a.disparo(pistol)){
                System.out.println(aux.getName() + " HAS DIED");
                break;
            }
        }
    }

}
