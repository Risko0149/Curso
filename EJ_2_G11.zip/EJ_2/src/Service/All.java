/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidades.Jugador;
import Entidades.Revolver;
import java.util.Random;

/**
 *
 * @author tomyv
 */
public class All {
    
    
    private Random rand = new Random();
    private Jugador jug = new Jugador();

    // • llenarRevolver(): le pone los valores de posición actual y de posición del agua. Los valores deben ser aleatorios.
    public void llenarRevolver(Revolver rev) {
        int tam = rand.nextInt(6)+1;
        rev.setPosTambor(tam);
        int agua = rand.nextInt(6)+1;
        rev.setPosAgua(agua);
        System.out.println(rev.getPosTambor() + " y " + rev.getPosAgua());
    }

    // • mojar(): devuelve true si la posición del agua coincide con la posición actual.
    public boolean mojar(Revolver rev) {
        return rev.getPosAgua() == rev.getPosTambor();
    }

    // • siguienteChorro(): cambia a la siguiente posición del tambor.
    public void siguienteChorro(Revolver rev) {
        if (rev.getPosTambor() == 6) {
            rev.setPosTambor(1);
        } else {
            rev.setPosAgua(rev.getPosAgua() + 1);

        }
    }

    // • toString(): muestra información del revolver (posición actual y donde está el agua).
    public void tooString(Revolver rev) {
        System.out.println(rev.toString());
    }
    
    // • disparo(Revolver r): el método, recibe el revolver de agua y llama a los métodos de
    //mojar() y siguienteChorro() de Revolver. El jugador se apunta, aprieta el gatillo y si el
    //revolver tira el agua, el jugador se moja. El atributo mojado pasa a false y el método
    //devuelve true, sino false.
    public boolean disparo(Revolver r){
        if(mojar(r)){
            System.out.println("GAME OVER , MY FRIEND");
            return true;
        }else{
            jug.setMojado(false);
            siguienteChorro(r);
            return false;
        }
    }
    
   
    
    
}
